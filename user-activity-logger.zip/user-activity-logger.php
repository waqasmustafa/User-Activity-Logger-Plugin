<?php
/*
Plugin Name: User Activity Logger
Description: Logs user activity on the website.
Version: 1.0
Author: Waqas
*/

// Activation hook
register_activation_hook(__FILE__, 'user_activity_logger_activate');

function user_activity_logger_activate() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'user_activity_log';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        timestamp datetime NOT NULL,
        ip_address varchar(45) NOT NULL,
        user_agent text NOT NULL,
        action varchar(255) NOT NULL,
        page_url text NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function log_user_activity($action, $user_agent, $page_url) {
    global $wpdb;

    $timestamp = current_time('mysql');
    $ip_address = $_SERVER['REMOTE_ADDR'];

    $table_name = $wpdb->prefix . 'user_activity_log';
    $wpdb->insert(
        $table_name,
        array(
            'timestamp'  => $timestamp,
            'ip_address' => $ip_address,
            'user_agent' => $user_agent,
            'action'     => $action,
            'page_url'   => $page_url,
        )
    );
}

function user_activity_menu() {
    add_menu_page(
        'User Activity Logs',
        'Activity Logs',
        'manage_options',
        'user-activity-logs',
        'user_activity_logs_page'
    );
}

function user_activity_logs_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'user_activity_log';

    $logs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY timestamp DESC");

    echo '<div class="wrap">';
    echo '<h1>User Activity Logs</h1>';
    echo '<table class="widefat">';
    echo '<thead><tr><th>ID</th><th>Timestamp</th><th>IP Address</th><th>User Agent</th><th>Action</th><th>Page URL</th></tr></thead>';
    echo '<tbody>';
    
    foreach ($logs as $log) {
        echo '<tr>';
        echo '<td>' . esc_html($log->id) . '</td>';
        echo '<td>' . esc_html($log->timestamp) . '</td>';
        echo '<td>' . esc_html($log->ip_address) . '</td>';
        echo '<td>' . esc_html($log->user_agent) . '</td>';
        echo '<td>' . esc_html($log->action) . '</td>';
        echo '<td>' . esc_html($log->page_url) . '</td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}

add_action('admin_menu', 'user_activity_menu');

add_action('wp_footer', function () {
    $page_url = $_SERVER['REQUEST_URI'];
    log_user_activity('Page visit', $_SERVER['HTTP_USER_AGENT'], $page_url);
});
